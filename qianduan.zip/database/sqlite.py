import sqlite3 as sl
import base64

import numpy as np

con = sl.connect('my.db')
with con:
    # con.execute("""
    #        CREATE TABLE error (
    #            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    #            type TEXT,
    #            time TEXT,
    #            date TEXT
    #        );
    #    """)
    # con.execute("""
    #        CREATE TABLE signs (
    #            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    #            type TEXT,
    #            time TEXT,
    #            date TEXT
    #        );
    #    """)
    # f = open('a.png', 'rb')
    # pic = base64.b64encode(f.read()).decode('utf-8')
    # data_url = f'data:image/png;base64,{pic}'
    # con.execute("UPDATE error SET picture = :pic WHERE id = 0", {"pic": data_url})
    # con.commit()
    # f.close()
    breathing_data = np.random.rand(100) * 100
    # 将NumPy数组转换为字符串
    # breathing_data_str = np.array2string(breathing_data, precision=2, separator=', ', suppress_small=True)
    breathing_data_int = np.round(breathing_data).astype(int)
    breathing_data_str = np.array2string(breathing_data_int, precision=2, separator=', ', suppress_small=True)
    # print(breathing_data_str)
    con.execute("UPDATE signs SET line = :br WHERE id = 0", {"br": breathing_data_str})
    con.commit()
